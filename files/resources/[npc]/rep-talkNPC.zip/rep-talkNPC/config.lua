Config = {}
Config.Target = 'qb-target' -- // qb-target or qtarget, ox-tartget will auto conv
-- Config.Talk = 'Nói chuyện với %s'
Config.Talk = "Talk to %s"
Config.Color = {
    primaryColor = "#DE0059",  -- Button hover effect
    secondaryColor = "#2E67E7" -- Npc tag's box color
}
