if not Config.BossManagedOutfits then return end

if not Framework.ESX() then return end

function Management.RemoveItems()
    -- Do nothing
end

function Management.AddItems()
    -- Do nothing
end

function Management.AddBackMenuItem()
    -- Do nothing
end
