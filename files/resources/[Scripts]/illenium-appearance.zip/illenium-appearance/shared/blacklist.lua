Config.Blacklist = {
    male = {
        hair = {},
        components = {
            masks = {},
            upperBody = {},
            lowerBody = {},
            bags = {},
            shoes = {},
            scarfAndChains = {},
            shirts = {},
            bodyArmor = {},
            decals = {},
            jackets = {}
        },
        props = {
            hats = {},
            glasses = {},
            ear = {},
            watches = {},
            bracelets = {}
        }
    },
    female = {
        hair = {},
        components = {
            masks = {},
            upperBody = {},
            lowerBody = {},
            bags = {},
            shoes = {},
            scarfAndChains = {},
            shirts = {},
            bodyArmor = {},
            decals = {},
            jackets = {}
        },
        props = {
            hats = {},
            glasses = {},
            ear = {},
            watches = {},
            bracelets = {}
        }
    }
}
