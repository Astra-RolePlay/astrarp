fx_version 'adamant'
game 'gta5'
description 'D-Logging from Deun Services'
version '1.0'

lua54 'yes'

shared_script { 'log.lua' }
