ALTER TABLE `owned_vehicles` ADD COLUMN `name` varchar(255)  NULL;
ALTER TABLE `owned_vehicles` ADD COLUMN `price` int(11)  NULL;
ALTER TABLE `owned_vehicles` ADD COLUMN `category` varchar(255)  NULL;
ALTER TABLE `owned_vehicles` ADD COLUMN `categoryname` varchar(255)  NULL;
ALTER TABLE `owned_vehicles` ADD COLUMN `km` int(11)  NULL;
ALTER TABLE `owned_vehicles` ADD COLUMN `age` varchar(255)  NULL;
ALTER TABLE `owned_vehicles` ADD COLUMN `fuel` int(11)  NULL;

