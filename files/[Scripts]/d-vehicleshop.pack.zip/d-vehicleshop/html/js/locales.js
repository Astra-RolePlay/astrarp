var locale = new Object();
locale['vehicle'] = 'Vehicle';
locale['search'] = 'Search';
locale['actions'] = 'Actions';
locale['vehicleshop'] = 'Vehicleshop';
locale['BACK'] = 'BACK';
locale['primarycolor'] = 'PRIMARY COLOR';
locale['secondarycolor'] = 'SECONDARY COLOR';
locale['plate'] = 'PLATE';
locale['selectancolor'] = 'Please select an color';
locale['ACCEPT'] = 'ACCEPT';
locale['Speed'] = 'Speed';
locale['Acceleration'] = 'Acceleration';
locale['Handling'] = 'Handling';
locale['Braking'] = 'Braking';
locale['TEST DRIVE'] = 'TEST DRIVE';
locale['CUSTOMIZE'] = 'CUSTOMIZE';
locale['Braking'] = 'Braking';
locale['sellvehicleconformation'] =
  'Are you sure you want to buy this vehicle for <font id="unpark-price"> 30.000 </font>?';
locale['remainingtime'] = 'Remaining Time';
locale['Braking'] = 'Braking';
locale['Presstostop'] =
  'Press <font id="testdrive-stopkey">H</font> to end the test drive';

locale['buy'] = 'BUY';
locale['selectthecar'] = 'Select the car';
locale['couldntfoundvehicle'] = 'Couldnt found vehicle';

locale['accept'] = 'Accept';
locale['decline'] = 'Decline';

locale['enteranplate'] = 'Enter the plate you want to use';

locale['Cash'] = 'Cash';
locale['Card'] = 'Card';
