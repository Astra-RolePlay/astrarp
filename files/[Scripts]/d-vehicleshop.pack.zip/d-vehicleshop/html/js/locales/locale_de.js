localede = new Object();
localede['vehicle'] = 'Fahrzeug';
localede['search'] = 'Suchen';
localede['actions'] = 'Aktionen';
localede['vehicleshop'] = 'Fahrzeug-Shop';
localede['BACK'] = 'ZURÜCK';
localede['primarycolor'] = 'HAUPTFARBE';
localede['secondarycolor'] = 'ZWEITFARBE';
localede['plate'] = 'KENNZEICHEN';
localede['selectancolor'] = 'Bitte wähle eine Farbe';
localede['ACCEPT'] = 'AKZEPTIEREN';
localede['Speed'] = 'Geschwindigkeit';
localede['Acceleration'] = 'Beschleunigung';
localede['Handling'] = 'Handling';
localede['Braking'] = 'Bremsen';
localede['TEST DRIVE'] = 'TESTFAHRT';
localede['CUSTOMIZE'] = 'ANPASSEN';
localede['sellvehicleconformation'] =
  'Bestätige das du das das Fahrzeug für <font id="unpark-price"> 30.000 </font> kaufen möchtest.';
localede['remainingtime'] = 'Verbleibende Zeit';
localede['Presstostop'] =
  'Drücke  <font id="testdrive-stopkey">H</font>, um die Testfahrt zu beenden';

localede['buy'] = 'KAUFEN';
localede['selectthecar'] = 'Wähle das Auto aus';
localede['couldntfoundvehicle'] = 'Fahrzeug konnte nicht gefunden werden';

localede['accept'] = 'Akzeptieren';
localede['decline'] = 'Ablehnen';

localede['enteranplate'] =
  'Geben Sie das Kennzeichen ein, das Sie verwenden möchten';
localede['Cash'] = 'Bargeld';
localede['Card'] = 'Karte';
