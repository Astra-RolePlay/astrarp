<IMPORTANT>
Join my Discord and read the messages in the #verify-your-payment channel
You received your transactionid in the email of tebex.

Discord Link > https://discord.gg/tngc5yN6mf

<INSTALLATION>
https://deun-services.gitbook.io/deun/d-vehicleshop/installation
